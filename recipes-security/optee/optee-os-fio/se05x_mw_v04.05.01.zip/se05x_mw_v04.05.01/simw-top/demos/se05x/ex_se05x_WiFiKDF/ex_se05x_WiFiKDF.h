/* Copyright 2019 NXP
 * SPDX-License-Identifier: Apache-2.0
 */

#include <ex_sss_objid.h>

/*Object ID where password is to be injected*/
#define WIFI_OBJ_ID (EX_SSS_OBJID_DEMO_WIFI_START + 1)
