#!/bin/bash

#
# Run from this directory only
#

function sed_SlotNumber() {
    git checkout -- sa_qi_provisioning/sa_qi_provisioning.h sa_qi_auth/sa_qi_auth.c
    sed_str1="s/#define QI_PROVISIONING_SLOT_ID 0/#define QI_PROVISIONING_SLOT_ID ${1}/g"
    sed_str2="s/#define EX_SLOT_ID 0x00/#define EX_SLOT_ID ${1}/g"
    sed -i "${sed_str1}" sa_qi_provisioning/sa_qi_provisioning.h
    sed -i "${sed_str2}" sa_qi_auth/sa_qi_auth.c
}

cd ..

sed_SlotNumber $1
