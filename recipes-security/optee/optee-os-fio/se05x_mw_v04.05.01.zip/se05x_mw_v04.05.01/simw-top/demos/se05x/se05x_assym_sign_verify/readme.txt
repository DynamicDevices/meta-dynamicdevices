For asymmetric sign and verify example, refer \simw-top\sss\ex\asymmetric

