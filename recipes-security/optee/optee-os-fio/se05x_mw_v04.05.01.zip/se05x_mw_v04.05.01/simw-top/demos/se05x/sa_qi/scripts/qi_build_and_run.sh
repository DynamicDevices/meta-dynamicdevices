# Copyright 2022 NXP
#
# This software is owned or controlled by NXP and may only be used
# strictly in accordance with the applicable license terms.  By expressly
# accepting such terms or by downloading, installing, activating and/or
# otherwise using the software, you are agreeing that you have read, and
# that you agree to comply with and are bound by, such license terms.  If
# you do not agree to be bound by the applicable license terms, then you
# may not retain, install, activate or otherwise use the software.
#
#
# Run this script from this folder only
#


SCRIPTS_DIR=`pwd`
SOURCE_DIR=${SCRIPTS_DIR}/../../../../
BUILD_DIR=${SOURCE_DIR}/../_linux_build/
cd ${SCRIPTS_DIR}

source ${SOURCE_DIR}/scripts/env_setup.sh
source ${SOURCE_DIR}/scripts/cmake_options.sh

if [ -e ${BUILD_DIR} ]; then
    rm -rf ${BUILD_DIR}
fi

set -u

mkdir ${BUILD_DIR}

cd ${BUILD_DIR}

cmake ${SOURCE_DIR} \
    ${doCMAKE_BUILD_TYPE_Release_ON} \
    ${doPTMW_SCP_SCP03_SSS_ON} \
    ${doPTMW_SMCOM_JRCP_V2_ON} \
    ${doNXPInternal_ON} \
    ${doPTMW_Applet_SE05X_C_ON} \
    ${doPTMW_SE05X_Ver_07_02_ON} \
    ${doPTMW_Host_PCLinux64_ON}

function doConfigureCmake() {
    cd ${BUILD_DIR}
    cmake $1 .
    make clean -j
}

function buildBinaries_PCLinux() {
    TARGET="$1"
    cd ${BUILD_DIR}
    make ${TARGET} -j
    cp bin/${TARGET} bin/${TARGET}_$2
}

function doConfigureSlotId() {
    cd ${SCRIPTS_DIR}
    ./sed_slotid.sh $1
    cd ${BUILD_DIR}
}

function doBuildProvisioning {
    doConfigureSlotId $1
    buildBinaries_PCLinux "sa_qi_provisioning" $1
}

function doBuildAuth {
    doConfigureSlotId $1
    buildBinaries_PCLinux "sa_qi_auth" $1
}

##################################
# Build for 07_02 - Provisioning #
##################################

cmake -L .
doConfigureCmake "${doPTMW_SE05X_Auth_AESKey_PlatfSCP03_ON}"
doBuildProvisioning 0
doBuildProvisioning 1
doBuildProvisioning 2
doBuildProvisioning 3


##########################
# Build for 07_02 - Auth #
##########################

doConfigureCmake "${doPTMW_SE05X_Auth_None_ON}"
doBuildAuth 0
doBuildAuth 1
doBuildAuth 2
doBuildAuth 3

cd ${BUILD_DIR}

./bin/sa_qi_provisioning_0 > ${SCRIPTS_DIR}/log_0.txt
./bin/sa_qi_auth_0 >> ${SCRIPTS_DIR}/log_0.txt
./bin/sa_qi_provisioning_1 > ${SCRIPTS_DIR}/log_1.txt
./bin/sa_qi_auth_1 >> ${SCRIPTS_DIR}/log_1.txt
./bin/sa_qi_provisioning_2 > ${SCRIPTS_DIR}/log_2.txt
./bin/sa_qi_auth_2 >> ${SCRIPTS_DIR}/log_2.txt
./bin/sa_qi_provisioning_3 > ${SCRIPTS_DIR}/log_3.txt
./bin/sa_qi_auth_3 >> ${SCRIPTS_DIR}/log_3.txt
