/* Copyright 2019 NXP
 * SPDX-License-Identifier: Apache-2.0
 */

#ifndef DEMOS_KSDK_PROVISIONING_PROVISIONING_H_
#define DEMOS_KSDK_PROVISIONING_PROVISIONING_H_

#include <ex_sss.h>
#include <ex_sss_boot.h>

#endif /* DEMOS_KSDK_PROVISIONING_PROVISIONING_H_ */
